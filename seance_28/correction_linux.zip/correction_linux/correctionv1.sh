#!/bin/bash
if [ "$TERM" != "dumb" ]; then
    ROUGE=$(tput setaf 1)
    VERT=$(tput setaf 2)
    JAUNE=$(tput setaf 3)
    BLEU=$(tput setaf 12)
    ROSE=$(tput setaf 5)
    CYAN=$(tput setaf 6)
    NORMAL=$(tput sgr0)
    GRIS=$(tput setaf 15)
    GRISFONCE=$(tput setaf 8)
    BLANC=$(tput setaf 7)
    BLANCLAIR=$(tput setaf 15)
    GRAS=$(tput bold)
fi

titre () {
  texte=${1:-""}
  couleur=${2:-$BLANCLAIR}
  echo -e $couleur$GRAS"---------------------------------"
  echo -e "$texte"
  echo -e "---------------------------------"$NORMAL
}

suivant() {
  echo ""
  read -p "Appuyez sur ENTRÉE pour continuer..."
  clear
}

checkstart() {
  texte=${1:-""}
  tput cuf 12
  echo -e $NORMAL$texte
}

checkend() {
  texte=${1:-"OK"}
  col=$(( $( tput cols ) - 10 ))
  tput cuu 1
  tput cuf 2
  if [[ $texte == "OK" ]]; then
    echo -en $VERT
  elif [[ $texte == "SKIP" ]]; then
    echo -en $GRISFONCE
  else
    echo -en $ROUGE
  fi
  echo -e $GRAS$texte$NORMAL
}

checkifzero() {
	if [ $? -eq 0 ]; then
	  total=$(($total + 1))
	  checkend "OK"
	else
	  checkend "ERREUR"
	fi
	count=$(($count + 1))
}

checkifnotzero() {
	if [ ! $? -eq 0 ]; then
	  total=$(($total + 1))
	  checkend "OK"
	else
	  checkend "ERREUR"
	fi
	count=$(($count + 1))
}

verifserviceinstall() {
	nom=$1
	package=$2
	checkstart "Vérification de l'installation de $nom"
	if dpkg --get-selections | grep "$package" >/dev/null 2>&1; then
	  checkend "OK"
    return 0
	else
	  checkend "ERREUR"
    return 1
	fi
}

verifserviceup() {
	nom=$1
  service=$2
  skip=$3
	checkstart "Le service $nom est lancé et fonctionnel"
  if [[ $skip == 1 ]]; then
	  checkend "SKIP"
    return 1
  fi	
	if systemctl status $service.service | grep "active (running)" >/dev/null 2>&1; then
	  checkend "OK"
    return 0
	else
	  checkend "ERREUR"
    return 1
	fi
}

verifservicestart() {
	nom=$1
  service=$2
  skip=$3
	checkstart "Le service $nom est lancé au démarrage"
  if [[ $skip == 1 ]]; then
	  checkend "SKIP"
    return 1
  fi
	if systemctl is-enabled $service.service >/dev/null 2>&1; then
	  checkend "OK"
    return 0
	else
	  checkend "ERREUR"
    return 1
	fi
}

if [ "$(whoami)" != 'root' ]; then
    echo "Le script de correction doit être exécuté comme${GRAS} root$NORMAL"
    exit 1
fi

clear
origin_dir=$( pwd )

#
#
# Configuration réseau
#
#
total1=0 
titre "Vérification CONFIGURATION DU RÉSEAU"
checkstart "Vérification de l'adresse IP" 
if hostname --all-ip-addresses | grep "192.168.21.10" >/dev/null 2>&1; then
  total1=$(($total1 + 1))
  checkend "OK"
else
  checkend "ERREUR"
fi

checkstart "Vérification du masque réseau" 
if ip addr | grep "192.168.21.10/24" >/dev/null 2>&1; then
  total1=$(($total1 + 1))
  checkend "OK"
else
  checkend "ERREUR"
fi

checkstart "Vérification de la passerelle" 
if ip route | grep default | grep "via 192.168.21.1" >/dev/null 2>&1; then
  total1=$(($total1 + 1))
  checkend "OK"
else
  checkend "ERREUR"
fi

checkstart "Vérification de la passerelle" 
if systemd-resolve --status | grep "Current DNS Server" | grep "192.168.21.1" >/dev/null 2>&1; then
  total1=$(($total1 + 1))
  checkend "OK"
else
  checkend "ERREUR"
fi
echo ""



#
#
# Configuration des utilisateurs
#
#
total2=0
operateur=0
titre "Vérification CONFIGURATION DES UTILISATEURS"
checkstart "Création du compte 'operateur'"
if id -u operateur >/dev/null 2>&1; then
  total2=$(($total2 + 1))
  checkend "OK"
  operateur=1
else
  checkend "ERREUR"
fi

checkstart "Création du compte 'sauvegarde'"
if id -u sauvegarde >/dev/null 2>&1; then
  total2=$(($total2 + 1))
  checkend "OK"
else
  checkend "ERREUR"
fi

checkstart "Le compte 'operateur' est administrateur"
if [[ $operateur == 0 ]]; then
  checkend "SKIP"
else
  if groups operateur | grep "\bsudo\b" >/dev/null 2>&1; then
    total2=$(($total2 + 1))
    checkend "OK"
  else
    checkend "ERREUR"
  fi
fi
echo ""

#
#
# Configuration du second disque
#
#
total3=0
titre "Vérification CONFIGURATION DU DISQUE 2"
checkstart "Ajout du second disque"
if ls /dev/sdb >/dev/null 2>&1; then
  total3=$(($total3 + 1))
  checkend "OK"
else
  checkend "ERREUR"
fi

checkstart "Format de fichier ext4"
if lsblk -f | grep "sdb1" | grep "ext4" >/dev/null 2>&1; then
  total3=$(($total3 + 1))
  checkend "OK"
else
  checkend "ERREUR"
fi

checkstart "Disque monté dans /media/sauvegarde"
if lsblk -f | grep "sdb1" | grep "/media/sauvegarde" >/dev/null 2>&1; then
  total3=$(($total3 + 1))
  checkend "OK"
else
  checkend "ERREUR"
fi

checkstart "Disque monté au démarrage"
if grep "/dev/sdb1" /etc/fstab | grep "/media/sauvegarde" | grep "defaults" | grep "ext4" >/dev/null 2>&1; then
  total3=$(($total3 + 1))
  checkend "OK"
else
  checkend "ERREUR"
fi

checkstart "Propriétaire et groupe du dossier /media/sauvegarde"
if stat -c "%U %G" /media/sauvegarde | grep "^sauvegarde sauvegarde$"  >/dev/null 2>&1; then
  total3=$(($total3 + 1))
  checkend "OK"
else
  checkend "ERREUR"
fi

checkstart "Droits d'accès du dossier /media/sauvegarde"
if ls -l /media | grep sauvegarde | grep "drwx------" >/dev/null 2>&1; then
  total3=$(($total3 + 1))
  checkend "OK"
else
  checkend "ERREUR"
fi

echo ""


#
#
# Configuration des services
#
#
total4=0
titre "Vérification CONFIGURATION DES SERVICES"

skip=1
if verifserviceinstall Apache apache2; then
  total4=$(($total4 + 1))
  skip=0
fi

if verifserviceup Apache apache2 $skip; then
  total4=$(($total4 + 1))
fi
if verifservicestart Apache apache2 $skip; then
  total4=$(($total4 + 1))
fi

skip=1
if verifserviceinstall SSH openssh-server; then
  total4=$(($total4 + 1))
  skip=0
fi

if verifserviceup SSH sshd $skip; then
  total4=$(($total4 + 1))
fi
if verifservicestart SSH sshd $skip; then
  total4=$(($total4 + 1))
fi

skip=1
checkstart "Vérification de l'installation de Turbine"
if ls -l /usr/lib/systemd/system/ | grep "turbined.service" >/dev/null 2>&1; then
  checkend "OK"    
  total4=$(($total4 + 1))
  skip=0
else
  checkend "ERREUR"
fi

if verifserviceup Turbine turbined $skip; then
  total4=$(($total4 + 1))
fi
if verifservicestart Turbine turbined $skip; then
  total4=$(($total4 + 1))
fi
echo ""

#
#
# Configuration des scripts
#
#
total5=0
titre "Vérification CONFIGURATION DES SCRIPTS"

skip=1
checkstart "Le script /home/operateur/maintenance existe"
if ls /home/operateur/maintenance.sh >/dev/null 2>&1; then
  total5=$(($total5 + 1))
  checkend "OK"
  skip=0
else
  checkend "ERREUR"
fi

checkstart "Le script de maintenance est exécutable"
if [[ $skip == 1 ]]; then
  checkend "SKIP"
else
  if ls -l /home/operateur | grep "maintenance.sh" | grep "^-rwx" >/dev/null 2>&1; then
    total5=$(($total5 + 1))
    checkend "OK"
  else
    checkend "ERREUR"
  fi
fi

skip=1
checkstart "Le script /home/sauvegarde/echantillon.sh existe"
if ls /home/sauvegarde/echantillon.sh >/dev/null 2>&1; then
  total5=$(($total5 + 1))
  checkend "OK"
  skip=0
else
  checkend "ERREUR"
fi

checkstart "Le script d'échantillonnage est exécutable"
if [[ $skip == 1 ]]; then
  checkend "SKIP"
else
  if ls -l /home/sauvegarde | grep "echantillon.sh" | grep "^-rwx" >/dev/null 2>&1; then
    total5=$(($total5 + 1))
    checkend "OK"
  else
    checkend "ERREUR"
  fi
fi

checkstart "La tâche planifiée est créée"
if crontab -u sauvegarde -l | grep -E '\*.+\*.+\*.+\*.+\*.+/home/sauvegarde/echantillon.sh' >/dev/null 2>&1; then
  total5=$(($total5 + 1))
  checkend "OK"
  skip=0
else
  checkend "ERREUR"
fi

echo ""

if [[ $1 == "--all" ]]; then
  total=$(($total1 + $total2 + $total3 + $total4 + $total5))
  echo "" 
  echo -e $CYAN"Total des points : $total/100" $NORMAL
  echo ""
fi

cd $origin_dir
